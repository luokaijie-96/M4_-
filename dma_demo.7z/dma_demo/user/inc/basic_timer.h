#ifndef __BASIC_TIMER_H__
#define __BASIC_TIMER_H__

#include "stm32f4xx.h"

void basic_timer_delay_ms(uint32_t nms);
void basic_timer_ms_irq(uint32_t nms);

#endif
