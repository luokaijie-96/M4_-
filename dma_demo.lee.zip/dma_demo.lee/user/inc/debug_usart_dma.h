#ifndef __DEBUG_USART_DMA_H__
#define __DEBUG_USART_DMA_H__


#include "stm32f4xx.h"

void debug_usart_dma_init(void);
void debug_usart_dma_send_ctrl(uint8_t *memory_address, uint16_t data_value);

#endif
