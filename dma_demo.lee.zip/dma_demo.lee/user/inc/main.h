#ifndef __MAIN_H__
#define __MAIN_H__


#include "stm32f4xx.h"
#include "led.h"
#include "key.h"
#include "debug_usart.h"
#include <string.h>
#include "systick.h"
#include "basic_timer.h"
#include "debug_usart_dma.h"

#endif
