#ifndef __KEY_INPUT_H__
#define __KEY_INPUT_H__

#include "stm32f4xx.h"

void key_timer_input_init(void);

#endif
