#ifndef __PWM_INPUT_H__
#define __PWM_INPUT_H__


#include "stm32f4xx.h"

void pwm_input_init(void);

#endif
