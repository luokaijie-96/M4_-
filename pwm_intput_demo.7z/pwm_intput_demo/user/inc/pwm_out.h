#ifndef __PWM_OUT_H__
#define __PWM_OUT_H__

#include "stm32f4xx.h"

void pwm_out_init(void);

#endif
