#ifndef __DEBUG_USART_H__
#define __DEBUG_USART_H__

#include "stm32f4xx.h"

#define DEBUG_USART_BOUND    115200

void debug_usart_init(void);
void dubug_usart_write_byte_data(uint8_t writedata);
uint8_t dubug_usart_read_byte_data(void);
void debug_usart_recivied_string(uint8_t *string);

#endif
