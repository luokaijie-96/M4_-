#ifndef __SYSTICK_H__
#define __SYSTICK_H__


#include "stm32f4xx.h"

void systick_delay_ms(uint32_t nms);
void systick_ms_irq_init(uint32_t nms);

#endif 
